#!/bin/bash

# This is an example installation script! For opne automatically google chrome by ramana
#happy codin
#google-chrome --kiosk http://www.thehbcreations.com/erl-np/
google-chrome --start--fullscreen --app=http://www.thehbcreations.com/erl-np/

